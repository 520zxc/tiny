# 设置权限
set_perm_recursive "$MODPATH" 0 0 0755 0755

echo "**********************清**********************"

sleep 2

echo "**********************清**********************"
echo "- 正在刷入[lsp]"
echo "**********************清**********************"

magisk --install-module "$MODPATH/yc/1.zip"

echo "- 正在刷入来自[PlayIntegrityFix_Flander]"
echo "**********************清**********************"

magisk --install-module "$MODPATH/yc/2.zip"

echo "- 正在刷入来自[Zygisk Next]"
echo "**********************清**********************"

magisk --install-module "$MODPATH/yc/3.zip"

echo "- 正在刷入来自[PlayIntegrityFix_Flander]"
echo "**********************清**********************"

magisk --install-module "$MODPATH/yc/4.zip"

echo "- 正在刷入来自[Shamiko]"
echo "**********************清**********************"

magisk --install-module "$MODPATH/yc/5.zip"

echo "- 正在刷入来自[Zygisk Maphide]"
echo "**********************清**********************"

magisk --install-module "$MODPATH/yc/6.zip"

echo "- 正在刷入来自[Tricky Store]"
echo "**********************清**********************"

magisk --install-module "$MODPATH/yc/7.zip"

echo "- 正在刷入来自[轻型过检测]"
echo "**********************清**********************"

magisk --install-module "$MODPATH/yc/8.zip"