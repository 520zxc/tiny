sleep 60
rm -rf "/data/adb/modules/yc"